insert into technical_support values (10001, 'Anant Shri Panthri', 'M', 7727636693, 'Level L3');

insert into technical_support values (10003, 'Tejashree Pandit', 'F', 9727554603, 'Level L1, L2');