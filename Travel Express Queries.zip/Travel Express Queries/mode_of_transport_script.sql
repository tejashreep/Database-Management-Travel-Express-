INSERT INTO Mode_OF_Transport VALUES
  (1001,'Air'
  );
INSERT INTO Mode_OF_Transport VALUES
  (2001,'Train'
  );
INSERT INTO Mode_OF_Transport VALUES
  (3001,'Road'
  );
  
select * from MODE_OF_TRANSPORT;  