select * from region;

select * from hotel;

select * from MODE_OF_TRANSPORT;

INSERT into hotel
values (16, 1, 'New York', 'Hampton Inn Manhattan', 'Times Square', '220 West 41st St., New York, NY, 10036 United States', '888-724-6413', 4, 
'Bed and Breakfast', 'Single Room with King Bed', '$249' )

insert into region
values (16, 'New York',	'NY',	40.74838,	-73.996705)