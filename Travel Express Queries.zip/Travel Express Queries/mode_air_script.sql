insert into mode_air values(1001,'Air','AIR001','Spirit','0.17');
insert into mode_air values(1001,'Air','AIR002','Southwest','0.25');
insert into mode_air values(1001,'Air','AIR003','American','0.19');
insert into mode_air values(1001,'Air','AIR004','Delta','0.22');
insert into mode_air values(1001,'Air','AIR005','Frontier','0.20');
insert into mode_air values(1001,'Air','AIR006','JetBlue','0.22');
insert into mode_air values(1001,'Air','AIR007','Alaska','0.27');
insert into mode_air values(1001,'Air','AIR008','Hawaiin','0.23');
insert into mode_air values(1001,'Air','AIR009','CSX','0.09');

select * from mode_air;