insert into user_support values (10002, 'Khyati Mishra', 'F', 9327626183, 'Travel Issues');
insert into user_support values (10003, 'Tejashree Pandit', 'F', 9727554603, 'Hotel Issues');