insert into customer_support values (10001, 'Anant Shri Panthri', 'M', 7727636693);
insert into customer_support values (10002, 'Khyati Mishra', 'F', 9327626183);
insert into customer_support values (10003, 'Tejashree Pandit', 'F', 9727554603);