
insert into mode_road values(3001,'Road','RD001','Greyhound Lines','0.05');
insert into mode_road values(3001,'Road','RD002','MetroBus','0.04');
insert into mode_road values(3001,'Road','RD003','Amtrak Thruway Motorcoach','0.20');
insert into mode_road values(3001,'Road','RD004','Jefferson Lines','0.10');
insert into mode_road values(3001,'Road','RD005','Peter Pan Bus Lines','0.08');

select * from mode_road;