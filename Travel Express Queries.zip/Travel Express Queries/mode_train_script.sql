insert into mode_train values(2001,'Train','TR001','Kansas City Southern Railway','0.07');
insert into mode_train values(2001,'Train','TR002','Norfolk Southern Railway','0.08');
insert into mode_train values(2001,'Train','TR003','CSX Transportation','0.11');
insert into mode_train values(2001,'Train','TR004','Union Pacific Railroad','0.09');
insert into mode_train values(2001,'Train','TR005','BNSF Railway','0.13');
insert into mode_train values(2001,'Train','TR006','Amtrak','0.10');

select * from MODE_TRAIN;