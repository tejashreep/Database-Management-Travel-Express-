insert into Offers values(1,'HALLOWEEN20','20%','Minimum booking of $200');
insert into Offers values(2,'DIWALI40','40%','Minimum booking of $200');
insert into Offers values(3,'HONEYMOON20','20%','Minimum booking of $200');
insert into Offers values(4,'FALL45','45%','Minimum booking of $500');
insert into Offers values(5,'SUMMER30','30%','Minimum booking of $500');
insert into Offers values(6,'SPRING20','20%','Minimum booking of $200');
insert into Offers values(7,'BLACKFRIDAY70','70%','Minimum booking of $800');
insert into Offers values(8,'CHRISTMAS560','60%','Minimum booking of $500');
insert into Offers values(9,'WEDDING20','20%','Minimum booking of $500');
insert into Offers values(10,'ANNIVERSARY20','20%','Minimum booking of $200 and proof of Anniversary');
insert into Offers values(11,'HALLOWEEN30','30%','Minimum booking of $400');
insert into Offers values(12,'HALLOWEEN40','20%','Minimum booking of $600');
insert into Offers values(13,'HALLOWEEN123','20%','Minimum booking of $200');
insert into Offers values(14,'CHRISTMAS550','50%','Minimum booking of $500');
insert into Offers values(15,'HALLOWEEN23','23%','Minimum booking of $100');
insert into Offers values(16,'CHRISTMAS580','80%','Minimum booking of $100');
insert into Offers values(17,'HALLOWEEN45','45%','Minimum booking of $300');
insert into Offers values(18,'BIRTHDAY20','20%','Minimum booking of $200 and proof of DOB');


